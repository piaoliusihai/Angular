import {Component, OnInit, Optional} from '@angular/core';

@Component({
  selector: 'app-spark-job-line',
  templateUrl: './spark-job-line.component.html',
  styleUrls: ['./spark-job-line.component.css']
})

export class SparkJobLineComponent {
  private static pattern = RegExp('^\\d{2}\\/\\d{2}\\/\\d{2} \\d{2}:\\d{2}:\\d{2} [a-zA-Z]+');
  private static typeToColorMap = new Map([
    ['DEBUG', '#8A2DA4'],
    ['ERROR', 'A4262C'],
    ['INFO', '#107C10'],
    ['System LOG', '#00188F'],
    ['WARN', '#B35F00'],
    ['Hyperlink', '#015CDA'],
    ['HyperlinkWithText', '#004578'],
    ['HtmlPersistentMessage', '#4D073F'],
    ['Default', '#323130']
  ]);
  content: string;
  logType: string;
  color: string;

  constructor() {
  }

  setFeild(content: string, prev: SparkJobLineComponent) {
    this.content = content;
    if (SparkJobLineComponent.pattern.test(content)) {
      this.logType = SparkJobLineComponent.pattern.exec(this.content)[0].split(' ')[2];
    } else {
      this.logType = ( prev == null ) ? 'Default' : prev.logType;
    }
    this.color = SparkJobLineComponent.typeToColorMap.get(this.logType);
  }
}
